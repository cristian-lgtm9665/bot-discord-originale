# Overview

This is a Discord moderation bot with a web dashboard built using a full-stack TypeScript architecture. The application provides real-time monitoring and management of Discord server moderation activities through both automated bot commands and a React-based web interface. The bot includes features like user leveling system, XP tracking, moderation actions (ban, kick, mute, etc.), and comprehensive statistics tracking.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for development tooling
- **Styling**: Tailwind CSS with a custom dark theme design system
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent, accessible components
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite with custom aliases and path resolution for clean imports

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API endpoints for bot statistics, user data, and moderation actions
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Database Schema**: PostgreSQL with tables for users, Discord users, moderation actions, and bot statistics
- **Bot Framework**: Discord.js v14 for Discord API integration

## Data Storage Solutions
- **Primary Database**: PostgreSQL (configured for Neon Database)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Storage Interface**: Abstract storage interface with in-memory implementation for development
- **Session Management**: PostgreSQL-based session storage using connect-pg-simple

## Authentication and Authorization
- **Session-based**: Express sessions with PostgreSQL storage
- **User Management**: Basic username/password authentication system
- **Discord Integration**: Discord bot token authentication for API access

## External Dependencies
- **Discord.js**: Core Discord bot functionality and API interactions
- **Neon Database**: Serverless PostgreSQL database hosting
- **Radix UI**: Headless UI primitives for accessible components
- **TanStack Query**: Server state management and caching
- **Tailwind CSS**: Utility-first CSS framework
- **Drizzle ORM**: Type-safe database toolkit
- **shadcn/ui**: Pre-built component library built on Radix UI
- **Lucide React**: Icon library for consistent iconography
- **Date-fns**: Date manipulation utilities
- **Class Variance Authority**: Component variant management
- **Wouter**: Lightweight routing library

## Key Features
- **Discord Bot Integration**: Real-time message monitoring, XP system, voice activity tracking
- **Moderation System**: Comprehensive moderation actions with duration support and automatic expiration
- **User Leveling**: XP-based progression system with progress tracking
- **Statistics Dashboard**: Real-time bot statistics, user rankings, and moderation history
- **Responsive Design**: Mobile-first design with dark theme support
- **Development Tools**: Hot reload, error overlays, and Replit-specific development plugins