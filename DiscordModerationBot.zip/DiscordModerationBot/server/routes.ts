import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { discordBot } from "./services/discord-bot";

export async function registerRoutes(app: Express): Promise<Server> {
  // Start Discord bot
  discordBot.start();

  // API Routes
  app.get("/api/bot-stats", async (req, res) => {
    try {
      const stats = await storage.getBotStats();
      const client = discordBot.getClient();
      
      const botInfo = {
        name: client.user?.username || 'ModerationBot',
        status: client.isReady() ? 'online' : 'offline',
        uptime: client.uptime || 0,
        guilds: client.guilds.cache.size,
      };

      res.json({ stats, botInfo });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bot stats" });
    }
  });

  app.get("/api/top-users", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const topUsers = await storage.getTopLevelUsers(limit);
      
      // Calculate progress for each user
      const usersWithProgress = topUsers.map(user => {
        const currentLevelXP = Math.pow(user.level - 1, 2) * 100;
        const nextLevelXP = Math.pow(user.level, 2) * 100;
        const progressXP = user.xp - currentLevelXP;
        const requiredXP = nextLevelXP - currentLevelXP;
        const progressPercent = Math.floor((progressXP / requiredXP) * 100);
        
        return {
          ...user,
          progressPercent,
          progressXP,
          requiredXP,
        };
      });

      res.json(usersWithProgress);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch top users" });
    }
  });

  app.get("/api/moderation-actions", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const actions = await storage.getModerationActions(limit);
      res.json(actions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch moderation actions" });
    }
  });

  app.get("/api/command-stats", async (req, res) => {
    try {
      const actions = await storage.getModerationActions(1000); // Get more for stats
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const commandStats = {
        ban: {
          usesToday: actions.filter(a => a.type === 'ban' && a.createdAt && a.createdAt >= today).length,
          successRate: 100, // Simplified - could be calculated based on failed attempts
        },
        unban: {
          usesToday: actions.filter(a => a.type === 'unban' && a.createdAt && a.createdAt >= today).length,
          successRate: 100,
        },
        kick: {
          usesToday: actions.filter(a => a.type === 'kick' && a.createdAt && a.createdAt >= today).length,
          successRate: 95,
        },
        mute: {
          usesToday: actions.filter(a => a.type === 'mute' && a.createdAt && a.createdAt >= today).length,
          activeMutes: actions.filter(a => a.type === 'mute' && a.isActive).length,
        },
        unmute: {
          usesToday: actions.filter(a => a.type === 'unmute' && a.createdAt && a.createdAt >= today).length,
          successRate: 100,
        },
        clear: {
          usesToday: actions.filter(a => a.type === 'clear' && a.createdAt && a.createdAt >= today).length,
          messagesCleared: actions.filter(a => a.type === 'clear' && a.createdAt && a.createdAt >= today).reduce((sum, a) => sum + (a.messageCount || 0), 0),
        },
        livello: {
          usesToday: 0, // Would need to track this separately
          totalQueries: 0,
        }
      };

      res.json(commandStats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch command stats" });
    }
  });

  app.post("/api/refresh-bot", async (req, res) => {
    try {
      const client = discordBot.getClient();
      if (client.isReady()) {
        // Update stats
        const stats = await storage.getBotStats();
        res.json({ message: "Bot refreshed successfully", stats });
      } else {
        res.status(503).json({ message: "Bot is not ready" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to refresh bot" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
