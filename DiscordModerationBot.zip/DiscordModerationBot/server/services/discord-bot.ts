import { Client, GatewayIntentBits, SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChatInputCommandInteraction, VoiceState, Message, TextChannel } from 'discord.js';
import { storage } from '../storage';

class DiscordBot {
  private client: Client;
  private token: string;

  constructor() {
    this.token = process.env.DISCORD_BOT_TOKEN || 'MTQxNzk4MTk3Mjc5NzQ1NjQ1Ng.GDxtQ3.xqVibJdTFO-jIa2Vgf2FT3pUvs0ahMlMMWCM28';
    
    this.client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMembers,
      ],
    });

    this.setupEventListeners();
    this.setupCommands();
  }

  private setupEventListeners() {
    this.client.once('ready', () => {
      console.log(`Bot is ready! Logged in as ${this.client.user?.tag}`);
      this.updateBotStats();
    });

    // XP system for messages
    this.client.on('messageCreate', async (message: Message) => {
      if (message.author.bot || !message.guild) return;

      const userId = message.author.id;
      const username = message.author.username;
      
      let user = await storage.getDiscordUser(userId);
      if (!user) {
        user = await storage.createDiscordUser({
          id: userId,
          username,
          discriminator: message.author.discriminator,
          level: 1,
          xp: 0,
          messageCount: 0,
          voiceJoins: 0,
        });
      }

      // Check if enough time has passed since last message (prevent spam)
      const now = new Date();
      if (user.lastMessageTime) {
        const timeDiff = now.getTime() - user.lastMessageTime.getTime();
        if (timeDiff < 60000) return; // 1 minute cooldown
      }

      const newXp = user.xp + 15;
      const newLevel = Math.floor(Math.sqrt(newXp / 100)) + 1;
      const leveledUp = newLevel > user.level;

      await storage.updateDiscordUser(userId, {
        xp: newXp,
        level: newLevel,
        messageCount: user.messageCount + 1,
        lastMessageTime: now,
      });

      if (leveledUp) {
        const embed = new EmbedBuilder()
          .setTitle('🎉 Level Up!')
          .setDescription(`Congratulations ${username}! You reached level ${newLevel}!`)
          .setColor(0x5865F2);
        
        if (message.channel.isSendable()) {
          message.channel.send({ embeds: [embed] });
        }
      }
    });

    // XP system for voice channel joins
    this.client.on('voiceStateUpdate', async (oldState: VoiceState, newState: VoiceState) => {
      if (!newState.member?.user || newState.member.user.bot) return;

      // User joined a voice channel
      if (!oldState.channel && newState.channel) {
        const userId = newState.member.user.id;
        const username = newState.member.user.username;

        let user = await storage.getDiscordUser(userId);
        if (!user) {
          user = await storage.createDiscordUser({
            id: userId,
            username,
            discriminator: newState.member.user.discriminator,
            level: 1,
            xp: 0,
            messageCount: 0,
            voiceJoins: 0,
          });
        }

        const newXp = user.xp + 50;
        const newLevel = Math.floor(Math.sqrt(newXp / 100)) + 1;
        const leveledUp = newLevel > user.level;

        await storage.updateDiscordUser(userId, {
          xp: newXp,
          level: newLevel,
          voiceJoins: user.voiceJoins + 1,
        });

        if (leveledUp && newState.guild) {
          const systemChannel = newState.guild.systemChannel;
          if (systemChannel) {
            const embed = new EmbedBuilder()
              .setTitle('🎉 Level Up!')
              .setDescription(`Congratulations ${username}! You reached level ${newLevel}!`)
              .setColor(0x5865F2);
            
            systemChannel.send({ embeds: [embed] });
          }
        }
      }
    });
  }

  private async setupCommands() {
    const commands = [
      // Ban command
      new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Ban a user from the server')
        .addUserOption(option =>
          option.setName('user')
            .setDescription('The user to ban')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('reason')
            .setDescription('Reason for the ban'))
        .addIntegerOption(option =>
          option.setName('duration')
            .setDescription('Ban duration in days (leave empty for permanent)'))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

      // Unban command
      new SlashCommandBuilder()
        .setName('unban')
        .setDescription('Unban a user from the server')
        .addStringOption(option =>
          option.setName('userid')
            .setDescription('The user ID to unban')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('reason')
            .setDescription('Reason for the unban'))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

      // Kick command
      new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Kick a user from the server')
        .addUserOption(option =>
          option.setName('user')
            .setDescription('The user to kick')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('reason')
            .setDescription('Reason for the kick'))
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

      // Mute command
      new SlashCommandBuilder()
        .setName('mute')
        .setDescription('Mute a user in the server')
        .addUserOption(option =>
          option.setName('user')
            .setDescription('The user to mute')
            .setRequired(true))
        .addIntegerOption(option =>
          option.setName('duration')
            .setDescription('Mute duration in minutes'))
        .addStringOption(option =>
          option.setName('reason')
            .setDescription('Reason for the mute'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

      // Unmute command
      new SlashCommandBuilder()
        .setName('unmute')
        .setDescription('Unmute a user in the server')
        .addUserOption(option =>
          option.setName('user')
            .setDescription('The user to unmute')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('reason')
            .setDescription('Reason for the unmute'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

      // Clear command
      new SlashCommandBuilder()
        .setName('clear')
        .setDescription('Clear messages from the channel')
        .addIntegerOption(option =>
          option.setName('amount')
            .setDescription('Number of messages to clear (1-100)')
            .setRequired(true)
            .setMinValue(1)
            .setMaxValue(100))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      // Level command
      new SlashCommandBuilder()
        .setName('livello')
        .setDescription('Check your or another user\'s level')
        .addUserOption(option =>
          option.setName('user')
            .setDescription('The user to check (leave empty for yourself)')),
    ];

    this.client.on('interactionCreate', async (interaction) => {
      if (!interaction.isChatInputCommand()) return;

      try {
        await this.handleCommand(interaction);
      } catch (error) {
        console.error('Error handling command:', error);
        const errorEmbed = new EmbedBuilder()
          .setTitle('❌ Error')
          .setDescription('An error occurred while executing the command.')
          .setColor(0xFF0000);

        if (interaction.deferred || interaction.replied) {
          await interaction.editReply({ embeds: [errorEmbed] });
        } else {
          await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
      }
    });

    // Register commands when bot is ready
    this.client.once('ready', async () => {
      if (!this.client.application) return;

      try {
        await this.client.application.commands.set(commands);
        console.log('Successfully registered application commands.');
      } catch (error) {
        console.error('Error registering commands:', error);
      }
    });
  }

  private async handleCommand(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) return;

    switch (interaction.commandName) {
      case 'ban':
        await this.handleBan(interaction);
        break;
      case 'unban':
        await this.handleUnban(interaction);
        break;
      case 'kick':
        await this.handleKick(interaction);
        break;
      case 'mute':
        await this.handleMute(interaction);
        break;
      case 'unmute':
        await this.handleUnmute(interaction);
        break;
      case 'clear':
        await this.handleClear(interaction);
        break;
      case 'livello':
        await this.handleLevel(interaction);
        break;
    }
  }

  private async handleBan(interaction: ChatInputCommandInteraction) {
    const targetUser = interaction.options.getUser('user', true);
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const duration = interaction.options.getInteger('duration');

    await interaction.deferReply();

    try {
      await interaction.guild!.members.ban(targetUser, { reason });

      // Log moderation action
      const expiresAt = duration ? new Date(Date.now() + duration * 24 * 60 * 60 * 1000) : null;
      await storage.createModerationAction({
        type: 'ban',
        targetUserId: targetUser.id,
        targetUsername: targetUser.username,
        moderatorId: interaction.user.id,
        moderatorUsername: interaction.user.username,
        reason,
        duration: duration ? duration * 24 * 60 : null,
        channelId: interaction.channelId,
        messageCount: null,
        isActive: true,
        expiresAt,
      });

      const embed = new EmbedBuilder()
        .setTitle('🔨 User Banned')
        .setDescription(`Successfully banned ${targetUser.username}`)
        .addFields(
          { name: 'Reason', value: reason },
          { name: 'Duration', value: duration ? `${duration} days` : 'Permanent' }
        )
        .setColor(0xFF0000);

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Ban Failed')
        .setDescription(`Failed to ban ${targetUser.username}. Check my permissions.`)
        .setColor(0xFF0000);

      await interaction.editReply({ embeds: [errorEmbed] });
    }
  }

  private async handleUnban(interaction: ChatInputCommandInteraction) {
    const userId = interaction.options.getString('userid', true);
    const reason = interaction.options.getString('reason') || 'No reason provided';

    await interaction.deferReply();

    try {
      const user = await this.client.users.fetch(userId);
      await interaction.guild!.members.unban(userId, reason);

      // Log moderation action
      await storage.createModerationAction({
        type: 'unban',
        targetUserId: userId,
        targetUsername: user.username,
        moderatorId: interaction.user.id,
        moderatorUsername: interaction.user.username,
        reason,
        duration: null,
        channelId: interaction.channelId,
        messageCount: null,
        isActive: true,
        expiresAt: null,
      });

      const embed = new EmbedBuilder()
        .setTitle('✅ User Unbanned')
        .setDescription(`Successfully unbanned ${user.username}`)
        .addFields({ name: 'Reason', value: reason })
        .setColor(0x00FF00);

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Unban Failed')
        .setDescription('Failed to unban user. Check the user ID and my permissions.')
        .setColor(0xFF0000);

      await interaction.editReply({ embeds: [errorEmbed] });
    }
  }

  private async handleKick(interaction: ChatInputCommandInteraction) {
    const targetUser = interaction.options.getUser('user', true);
    const reason = interaction.options.getString('reason') || 'No reason provided';

    await interaction.deferReply();

    try {
      const member = await interaction.guild!.members.fetch(targetUser.id);
      await member.kick(reason);

      // Log moderation action
      await storage.createModerationAction({
        type: 'kick',
        targetUserId: targetUser.id,
        targetUsername: targetUser.username,
        moderatorId: interaction.user.id,
        moderatorUsername: interaction.user.username,
        reason,
        duration: null,
        channelId: interaction.channelId,
        messageCount: null,
        isActive: true,
        expiresAt: null,
      });

      const embed = new EmbedBuilder()
        .setTitle('👢 User Kicked')
        .setDescription(`Successfully kicked ${targetUser.username}`)
        .addFields({ name: 'Reason', value: reason })
        .setColor(0xFF8800);

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Kick Failed')
        .setDescription(`Failed to kick ${targetUser.username}. Check my permissions.`)
        .setColor(0xFF0000);

      await interaction.editReply({ embeds: [errorEmbed] });
    }
  }

  private async handleMute(interaction: ChatInputCommandInteraction) {
    const targetUser = interaction.options.getUser('user', true);
    const duration = interaction.options.getInteger('duration') || 60; // Default 1 hour
    const reason = interaction.options.getString('reason') || 'No reason provided';

    await interaction.deferReply();

    try {
      const member = await interaction.guild!.members.fetch(targetUser.id);
      const timeoutEnd = new Date(Date.now() + duration * 60 * 1000);
      
      await member.timeout(duration * 60 * 1000, reason);

      // Log moderation action
      await storage.createModerationAction({
        type: 'mute',
        targetUserId: targetUser.id,
        targetUsername: targetUser.username,
        moderatorId: interaction.user.id,
        moderatorUsername: interaction.user.username,
        reason,
        duration,
        channelId: interaction.channelId,
        messageCount: null,
        isActive: true,
        expiresAt: timeoutEnd,
      });

      const embed = new EmbedBuilder()
        .setTitle('🔇 User Muted')
        .setDescription(`Successfully muted ${targetUser.username}`)
        .addFields(
          { name: 'Duration', value: `${duration} minutes` },
          { name: 'Reason', value: reason }
        )
        .setColor(0x888888);

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Mute Failed')
        .setDescription(`Failed to mute ${targetUser.username}. Check my permissions.`)
        .setColor(0xFF0000);

      await interaction.editReply({ embeds: [errorEmbed] });
    }
  }

  private async handleUnmute(interaction: ChatInputCommandInteraction) {
    const targetUser = interaction.options.getUser('user', true);
    const reason = interaction.options.getString('reason') || 'No reason provided';

    await interaction.deferReply();

    try {
      const member = await interaction.guild!.members.fetch(targetUser.id);
      await member.timeout(null, reason);

      // Log moderation action
      await storage.createModerationAction({
        type: 'unmute',
        targetUserId: targetUser.id,
        targetUsername: targetUser.username,
        moderatorId: interaction.user.id,
        moderatorUsername: interaction.user.username,
        reason,
        duration: null,
        channelId: interaction.channelId,
        messageCount: null,
        isActive: true,
        expiresAt: null,
      });

      const embed = new EmbedBuilder()
        .setTitle('🔊 User Unmuted')
        .setDescription(`Successfully unmuted ${targetUser.username}`)
        .addFields({ name: 'Reason', value: reason })
        .setColor(0x00FF00);

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Unmute Failed')
        .setDescription(`Failed to unmute ${targetUser.username}. Check my permissions.`)
        .setColor(0xFF0000);

      await interaction.editReply({ embeds: [errorEmbed] });
    }
  }

  private async handleClear(interaction: ChatInputCommandInteraction) {
    const amount = interaction.options.getInteger('amount', true);

    await interaction.deferReply({ ephemeral: true });

    try {
      const channel = interaction.channel as TextChannel;
      const messages = await channel.bulkDelete(amount, true);

      // Log moderation action
      await storage.createModerationAction({
        type: 'clear',
        targetUserId: 'N/A',
        targetUsername: 'N/A',
        moderatorId: interaction.user.id,
        moderatorUsername: interaction.user.username,
        reason: `Cleared ${messages.size} messages`,
        duration: null,
        channelId: interaction.channelId,
        messageCount: messages.size,
        isActive: true,
        expiresAt: null,
      });

      const embed = new EmbedBuilder()
        .setTitle('🧹 Messages Cleared')
        .setDescription(`Successfully cleared ${messages.size} messages`)
        .setColor(0x0099FF);

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Clear Failed')
        .setDescription('Failed to clear messages. Messages might be too old.')
        .setColor(0xFF0000);

      await interaction.editReply({ embeds: [errorEmbed] });
    }
  }

  private async handleLevel(interaction: ChatInputCommandInteraction) {
    const targetUser = interaction.options.getUser('user') || interaction.user;
    
    await interaction.deferReply();

    const discordUser = await storage.getDiscordUser(targetUser.id);
    
    if (!discordUser) {
      const embed = new EmbedBuilder()
        .setTitle('📊 Level Information')
        .setDescription(`${targetUser.username} hasn't gained any XP yet!`)
        .addFields(
          { name: 'Level', value: '1', inline: true },
          { name: 'XP', value: '0', inline: true },
          { name: 'Messages', value: '0', inline: true }
        )
        .setColor(0x5865F2);

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    const currentLevelXP = Math.pow(discordUser.level - 1, 2) * 100;
    const nextLevelXP = Math.pow(discordUser.level, 2) * 100;
    const progressXP = discordUser.xp - currentLevelXP;
    const requiredXP = nextLevelXP - currentLevelXP;
    const progress = Math.floor((progressXP / requiredXP) * 100);

    const embed = new EmbedBuilder()
      .setTitle('📊 Level Information')
      .setDescription(`Level information for ${targetUser.username}`)
      .addFields(
        { name: 'Level', value: discordUser.level.toString(), inline: true },
        { name: 'Total XP', value: discordUser.xp.toString(), inline: true },
        { name: 'Messages Sent', value: discordUser.messageCount.toString(), inline: true },
        { name: 'Voice Joins', value: discordUser.voiceJoins.toString(), inline: true },
        { name: 'Progress to Next Level', value: `${progressXP}/${requiredXP} XP (${progress}%)`, inline: false }
      )
      .setColor(0x5865F2);

    await interaction.editReply({ embeds: [embed] });
  }

  private async updateBotStats() {
    if (!this.client.guilds.cache.size) return;

    let totalUsers = 0;
    this.client.guilds.cache.forEach(guild => {
      totalUsers += guild.memberCount;
    });

    const activePunishments = (await storage.getActiveModerationActions()).length;
    const discordUsers = await storage.getAllDiscordUsers();
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const messagesDaily = discordUsers.reduce((sum, user) => {
      if (user.lastMessageTime && user.lastMessageTime >= today) {
        return sum + 1;
      }
      return sum;
    }, 0);

    await storage.updateBotStats({
      totalUsers,
      activePunishments,
      messagesDaily,
      voiceSessions: discordUsers.reduce((sum, user) => sum + user.voiceJoins, 0),
    });
  }

  public async start() {
    try {
      await this.client.login(this.token);
      console.log('Discord bot logged in successfully');
    } catch (error) {
      console.error('Failed to login to Discord:', error);
    }
  }

  public getClient() {
    return this.client;
  }
}

export const discordBot = new DiscordBot();
