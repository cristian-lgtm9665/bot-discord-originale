import { type User, type InsertUser, type DiscordUser, type InsertDiscordUser, type ModerationAction, type InsertModerationAction, type BotStats, type InsertBotStats } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Discord Users
  getDiscordUser(id: string): Promise<DiscordUser | undefined>;
  createDiscordUser(user: InsertDiscordUser): Promise<DiscordUser>;
  updateDiscordUser(id: string, updates: Partial<DiscordUser>): Promise<DiscordUser | undefined>;
  getAllDiscordUsers(): Promise<DiscordUser[]>;
  getTopLevelUsers(limit?: number): Promise<DiscordUser[]>;
  
  // Moderation Actions
  createModerationAction(action: InsertModerationAction): Promise<ModerationAction>;
  getModerationActions(limit?: number): Promise<ModerationAction[]>;
  getActiveModerationActions(): Promise<ModerationAction[]>;
  expireModerationAction(id: string): Promise<void>;
  
  // Bot Stats
  getBotStats(): Promise<BotStats | undefined>;
  updateBotStats(stats: Partial<BotStats>): Promise<BotStats>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private discordUsers: Map<string, DiscordUser>;
  private moderationActions: Map<string, ModerationAction>;
  private botStats: BotStats | undefined;

  constructor() {
    this.users = new Map();
    this.discordUsers = new Map();
    this.moderationActions = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getDiscordUser(id: string): Promise<DiscordUser | undefined> {
    return this.discordUsers.get(id);
  }

  async createDiscordUser(user: InsertDiscordUser): Promise<DiscordUser> {
    const discordUser: DiscordUser = {
      id: user.id,
      username: user.username,
      discriminator: user.discriminator || null,
      level: user.level || 1,
      xp: user.xp || 0,
      messageCount: user.messageCount || 0,
      voiceJoins: user.voiceJoins || 0,
      lastMessageTime: user.lastMessageTime || null,
      createdAt: new Date(),
    };
    this.discordUsers.set(user.id, discordUser);
    return discordUser;
  }

  async updateDiscordUser(id: string, updates: Partial<DiscordUser>): Promise<DiscordUser | undefined> {
    const user = this.discordUsers.get(id);
    if (!user) return undefined;

    const updatedUser = { ...user, ...updates };
    this.discordUsers.set(id, updatedUser);
    return updatedUser;
  }

  async getAllDiscordUsers(): Promise<DiscordUser[]> {
    return Array.from(this.discordUsers.values());
  }

  async getTopLevelUsers(limit = 10): Promise<DiscordUser[]> {
    const users = Array.from(this.discordUsers.values());
    return users.sort((a, b) => b.xp - a.xp).slice(0, limit);
  }

  async createModerationAction(action: InsertModerationAction): Promise<ModerationAction> {
    const id = randomUUID();
    const moderationAction: ModerationAction = {
      id,
      type: action.type,
      targetUserId: action.targetUserId,
      targetUsername: action.targetUsername,
      moderatorId: action.moderatorId,
      moderatorUsername: action.moderatorUsername,
      reason: action.reason || null,
      duration: action.duration || null,
      channelId: action.channelId || null,
      messageCount: action.messageCount || null,
      isActive: action.isActive !== undefined ? action.isActive : true,
      expiresAt: action.expiresAt || null,
      createdAt: new Date(),
    };
    this.moderationActions.set(id, moderationAction);
    return moderationAction;
  }

  async getModerationActions(limit = 50): Promise<ModerationAction[]> {
    const actions = Array.from(this.moderationActions.values());
    return actions.sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime()).slice(0, limit);
  }

  async getActiveModerationActions(): Promise<ModerationAction[]> {
    const actions = Array.from(this.moderationActions.values());
    const now = new Date();
    return actions.filter(action => 
      action.isActive && 
      (action.expiresAt === null || action.expiresAt > now)
    );
  }

  async expireModerationAction(id: string): Promise<void> {
    const action = this.moderationActions.get(id);
    if (action) {
      action.isActive = false;
      this.moderationActions.set(id, action);
    }
  }

  async getBotStats(): Promise<BotStats | undefined> {
    return this.botStats;
  }

  async updateBotStats(stats: Partial<BotStats>): Promise<BotStats> {
    if (!this.botStats) {
      this.botStats = {
        id: randomUUID(),
        totalUsers: 0,
        activePunishments: 0,
        messagesDaily: 0,
        voiceSessions: 0,
        commandUsage: '{}',
        lastUpdated: new Date(),
        ...stats,
      };
    } else {
      this.botStats = {
        ...this.botStats,
        ...stats,
        lastUpdated: new Date(),
      };
    }
    return this.botStats;
  }
}

export const storage = new MemStorage();
