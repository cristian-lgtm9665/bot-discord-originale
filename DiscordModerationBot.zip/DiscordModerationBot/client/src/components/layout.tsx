import { useQuery } from "@tanstack/react-query";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  TrendingUp,
  Shield, 
  RefreshCw,
  CheckCircle
} from "lucide-react";

interface BotStats {
  totalUsers: number;
  activePunishments: number;
  messagesDaily: number;
  voiceSessions: number;
}

interface BotInfo {
  name: string;
  status: 'online' | 'offline';
  uptime: number;
  guilds: number;
}

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { data: botData, refetch: refetchBot } = useQuery<{stats: BotStats, botInfo: BotInfo}>({
    queryKey: ['/api/bot-stats'],
    refetchInterval: 30000,
  });

  const handleRefresh = async () => {
    await refetchBot();
  };

  const formatUptime = (uptime: number) => {
    const hours = Math.floor(uptime / (1000 * 60 * 60));
    const minutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const navigationItems = [
    { path: "/", label: "Dashboard", icon: TrendingUp },
    { path: "/moderation", label: "Moderation", icon: Shield },
    { path: "/level-system", label: "Level System", icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-card border-r border-border flex flex-col">
          <div className="p-6 border-b border-border">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-foreground">Bot Manager</h1>
                <p className="text-sm text-muted-foreground">v2.1.0</p>
              </div>
            </div>
          </div>

          <nav className="flex-1 p-4 space-y-2">
            {navigationItems.map((item) => {
              const isActive = location === item.path;
              const Icon = item.icon;
              
              return (
                <Link key={item.path} href={item.path}>
                  <div className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors cursor-pointer w-full ${
                    isActive 
                      ? 'bg-primary text-primary-foreground' 
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  }`} data-testid={`nav-link-${item.path.replace('/', '') || 'dashboard'}`}>
                    <Icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </div>
                </Link>
              );
            })}
          </nav>

          {/* Bot Status */}
          <div className="p-4 border-t border-border">
            <div className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
              <div className={`w-3 h-3 rounded-full ${botData?.botInfo.status === 'online' ? 'bg-success' : 'bg-muted-foreground'}`}></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground" data-testid="bot-name">{botData?.botInfo.name || 'ModerationBot'}</p>
                <p className="text-xs text-muted-foreground" data-testid="bot-status">
                  {botData?.botInfo.status === 'online' ? 'Online' : 'Offline'}
                  {botData?.botInfo.uptime && ` - ${formatUptime(botData.botInfo.uptime)}`}
                </p>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto">
          {/* Header */}
          <header className="bg-card border-b border-border p-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-foreground">
                  {location === "/" && "Bot Dashboard"}
                  {location === "/moderation" && "Moderation Center"}
                  {location === "/level-system" && "Level System"}
                </h2>
                <p className="text-muted-foreground">
                  {location === "/" && "Manage your Discord bot's moderation and leveling features"}
                  {location === "/moderation" && "Manage server moderation and view recent actions"}
                  {location === "/level-system" && "Manage XP rewards and user progression"}
                </p>
              </div>
              <Button onClick={handleRefresh} className="bg-primary hover:bg-primary/90" data-testid="button-refresh">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </header>

          <div className="relative">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}