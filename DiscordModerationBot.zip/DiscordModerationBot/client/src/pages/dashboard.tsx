import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { 
  Users, 
  Shield, 
  MessageCircle, 
  Mic, 
  RefreshCw,
  Ban,
  UserX,
  Volume2,
  VolumeX,
  Trash2,
  TrendingUp,
  CheckCircle,
  AlertTriangle,
  Clock
} from "lucide-react";

interface BotStats {
  totalUsers: number;
  activePunishments: number;
  messagesDaily: number;
  voiceSessions: number;
}

interface BotInfo {
  name: string;
  status: 'online' | 'offline';
  uptime: number;
  guilds: number;
}

interface TopUser {
  id: string;
  username: string;
  level: number;
  xp: number;
  progressPercent: number;
  progressXP: number;
  requiredXP: number;
}

interface ModerationAction {
  id: string;
  type: string;
  targetUsername: string;
  moderatorUsername: string;
  reason: string | null;
  createdAt: Date;
  duration: number | null;
}

interface CommandStats {
  ban: { usesToday: number; successRate: number };
  unban: { usesToday: number; successRate: number };
  kick: { usesToday: number; successRate: number };
  mute: { usesToday: number; activeMutes: number };
  unmute: { usesToday: number; successRate: number };
  clear: { usesToday: number; messagesCleared: number };
  livello: { usesToday: number; totalQueries: number };
}

export default function Dashboard() {
  const { data: botData, refetch: refetchBot, isLoading: botLoading } = useQuery<{stats: BotStats, botInfo: BotInfo}>({
    queryKey: ['/api/bot-stats'],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const { data: topUsers, isLoading: usersLoading } = useQuery<TopUser[]>({
    queryKey: ['/api/top-users'],
    refetchInterval: 60000, // Refetch every minute
  });

  const { data: recentActions, isLoading: actionsLoading } = useQuery<ModerationAction[]>({
    queryKey: ['/api/moderation-actions'],
    refetchInterval: 10000, // Refetch every 10 seconds
  });

  const { data: commandStats, isLoading: commandStatsLoading } = useQuery<CommandStats>({
    queryKey: ['/api/command-stats'],
    refetchInterval: 60000,
  });

  const handleRefresh = async () => {
    await refetchBot();
  };

  const formatUptime = (uptime: number) => {
    const hours = Math.floor(uptime / (1000 * 60 * 60));
    const minutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) return `${hours} hours ago`;
    return `${minutes} minutes ago`;
  };

  const getActionIcon = (type: string) => {
    switch (type) {
      case 'ban': return <Ban className="w-4 h-4 text-destructive" />;
      case 'unban': return <CheckCircle className="w-4 h-4 text-success" />;
      case 'kick': return <UserX className="w-4 h-4 text-warning" />;
      case 'mute': return <VolumeX className="w-4 h-4 text-muted-foreground" />;
      case 'unmute': return <Volume2 className="w-4 h-4 text-success" />;
      case 'clear': return <Trash2 className="w-4 h-4 text-primary" />;
      default: return <Shield className="w-4 h-4" />;
    }
  };

  if (botLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Loading bot dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Users</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="stat-total-users">
                        {botData?.stats?.totalUsers?.toLocaleString() || '0'}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Users className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Active Punishments</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="stat-active-punishments">
                        {botData?.stats?.activePunishments || '0'}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
                      <AlertTriangle className="w-6 h-6 text-warning" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Messages Today</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="stat-messages-daily">
                        {botData?.stats?.messagesDaily?.toLocaleString() || '0'}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                      <MessageCircle className="w-6 h-6 text-success" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Voice Sessions</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="stat-voice-sessions">
                        {botData?.stats?.voiceSessions?.toLocaleString() || '0'}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                      <Mic className="w-6 h-6 text-accent" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Moderation Commands Panel */}
            <Card>
              <CardHeader>
                <CardTitle>Moderation Commands</CardTitle>
                <p className="text-sm text-muted-foreground">Manage user punishments and moderation tools</p>
              </CardHeader>
              <CardContent>
                {commandStatsLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {[...Array(6)].map((_, i) => (
                      <div key={i} className="border border-border rounded-lg p-4 animate-pulse">
                        <div className="h-6 bg-muted rounded mb-3"></div>
                        <div className="h-4 bg-muted rounded mb-2"></div>
                        <div className="h-3 bg-muted rounded"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-colors" data-testid="command-card-ban">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-destructive/10 rounded-lg flex items-center justify-center">
                            <Ban className="w-4 h-4 text-destructive" />
                          </div>
                          <span className="font-medium text-foreground">/ban</span>
                        </div>
                        <Badge variant="outline" className="text-xs bg-success/10 text-success border-success/20">Active</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">Permanently or temporarily ban users from the server</p>
                      <div className="text-xs text-muted-foreground space-y-1">
                        <div>Uses today: <span className="text-foreground">{commandStats?.ban.usesToday || 0}</span></div>
                        <div>Success rate: <span className="text-success">{commandStats?.ban.successRate || 100}%</span></div>
                      </div>
                    </div>

                    <div className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-colors" data-testid="command-card-unban">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
                            <CheckCircle className="w-4 h-4 text-success" />
                          </div>
                          <span className="font-medium text-foreground">/unban</span>
                        </div>
                        <Badge variant="outline" className="text-xs bg-success/10 text-success border-success/20">Active</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">Remove bans and restore user access to the server</p>
                      <div className="text-xs text-muted-foreground space-y-1">
                        <div>Uses today: <span className="text-foreground">{commandStats?.unban.usesToday || 0}</span></div>
                        <div>Success rate: <span className="text-success">{commandStats?.unban.successRate || 100}%</span></div>
                      </div>
                    </div>

                    <div className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-colors" data-testid="command-card-kick">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-warning/10 rounded-lg flex items-center justify-center">
                            <UserX className="w-4 h-4 text-warning" />
                          </div>
                          <span className="font-medium text-foreground">/kick</span>
                        </div>
                        <Badge variant="outline" className="text-xs bg-success/10 text-success border-success/20">Active</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">Remove users from the server without banning them</p>
                      <div className="text-xs text-muted-foreground space-y-1">
                        <div>Uses today: <span className="text-foreground">{commandStats?.kick.usesToday || 0}</span></div>
                        <div>Success rate: <span className="text-success">{commandStats?.kick.successRate || 95}%</span></div>
                      </div>
                    </div>

                    <div className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-colors" data-testid="command-card-mute">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-muted/50 rounded-lg flex items-center justify-center">
                            <VolumeX className="w-4 h-4 text-muted-foreground" />
                          </div>
                          <span className="font-medium text-foreground">/mute</span>
                        </div>
                        <Badge variant="outline" className="text-xs bg-success/10 text-success border-success/20">Active</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">Temporarily prevent users from sending messages</p>
                      <div className="text-xs text-muted-foreground space-y-1">
                        <div>Uses today: <span className="text-foreground">{commandStats?.mute.usesToday || 0}</span></div>
                        <div>Active mutes: <span className="text-warning">{commandStats?.mute.activeMutes || 0}</span></div>
                      </div>
                    </div>

                    <div className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-colors" data-testid="command-card-unmute">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
                            <Volume2 className="w-4 h-4 text-success" />
                          </div>
                          <span className="font-medium text-foreground">/unmute</span>
                        </div>
                        <Badge variant="outline" className="text-xs bg-success/10 text-success border-success/20">Active</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">Restore messaging privileges to muted users</p>
                      <div className="text-xs text-muted-foreground space-y-1">
                        <div>Uses today: <span className="text-foreground">{commandStats?.unmute.usesToday || 0}</span></div>
                        <div>Success rate: <span className="text-success">{commandStats?.unmute.successRate || 100}%</span></div>
                      </div>
                    </div>

                    <div className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-colors" data-testid="command-card-clear">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                            <Trash2 className="w-4 h-4 text-primary" />
                          </div>
                          <span className="font-medium text-foreground">/clear</span>
                        </div>
                        <Badge variant="outline" className="text-xs bg-success/10 text-success border-success/20">Active</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">Bulk delete messages from channels</p>
                      <div className="text-xs text-muted-foreground space-y-1">
                        <div>Uses today: <span className="text-foreground">{commandStats?.clear.usesToday || 0}</span></div>
                        <div>Messages cleared: <span className="text-primary">{commandStats?.clear.messagesCleared || 0}</span></div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Level System Panel */}
            <Card>
              <CardHeader>
                <CardTitle>Level System Configuration</CardTitle>
                <p className="text-sm text-muted-foreground">Manage XP rewards and user progression</p>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* XP Settings */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-medium text-foreground">XP Rewards</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg" data-testid="xp-setting-message">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
                            <MessageCircle className="w-4 h-4 text-success" />
                          </div>
                          <span className="text-sm text-foreground">Message XP</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium text-foreground">15</span>
                          <span className="text-xs text-muted-foreground">XP</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg" data-testid="xp-setting-voice">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center">
                            <Mic className="w-4 h-4 text-accent" />
                          </div>
                          <span className="text-sm text-foreground">Voice Join XP</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium text-foreground">50</span>
                          <span className="text-xs text-muted-foreground">XP</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-medium text-foreground">Level Command</h4>
                    <div className="p-4 bg-muted/30 rounded-lg" data-testid="level-command-info">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                          <TrendingUp className="w-4 h-4 text-primary" />
                        </div>
                        <span className="font-medium text-foreground">/livello</span>
                        <Badge variant="outline" className="text-xs bg-success/10 text-success border-success/20">Active</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">Check user level and XP progress</p>
                      <div className="text-xs text-muted-foreground space-y-1">
                        <div>Uses today: <span className="text-foreground">{commandStats?.livello.usesToday || 0}</span></div>
                        <div>Total queries: <span className="text-foreground">{commandStats?.livello.totalQueries || 0}</span></div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Top Users */}
                <div className="space-y-4">
                  <h4 className="font-medium text-foreground">Top Level Users</h4>
                  {usersLoading ? (
                    <div className="space-y-3">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg animate-pulse">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-muted rounded-full"></div>
                            <div>
                              <div className="h-4 w-20 bg-muted rounded mb-1"></div>
                              <div className="h-3 w-16 bg-muted rounded"></div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="h-4 w-16 bg-muted rounded mb-1"></div>
                            <div className="w-32 bg-muted rounded-full h-2"></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {topUsers && topUsers.length > 0 ? (
                        topUsers.slice(0, 3).map((user, index) => (
                          <div key={user.id} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg" data-testid={`top-user-${index}`}>
                            <div className="flex items-center space-x-3">
                              <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center">
                                <span className="text-sm font-bold text-primary-foreground">{index + 1}</span>
                              </div>
                              <div>
                                <p className="font-medium text-foreground" data-testid={`user-name-${index}`}>{user.username}</p>
                                <p className="text-sm text-muted-foreground">Level {user.level}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-medium text-foreground" data-testid={`user-xp-${index}`}>{user.xp.toLocaleString()} XP</p>
                              <div className="w-32 bg-border rounded-full h-2 mt-1">
                                <div 
                                  className="bg-gradient-to-r from-primary to-accent h-2 rounded-full" 
                                  style={{ width: `${Math.max(10, user.progressPercent)}%` }}
                                ></div>
                              </div>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-8 text-muted-foreground" data-testid="no-users-message">
                          <TrendingUp className="w-12 h-12 mx-auto mb-4 opacity-50" />
                          <p>No users have gained XP yet</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <p className="text-sm text-muted-foreground">Latest moderation actions and system events</p>
              </CardHeader>
              <CardContent>
                {actionsLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="flex items-start space-x-4 p-4 bg-muted/30 rounded-lg animate-pulse">
                        <div className="w-8 h-8 bg-muted rounded-lg mt-1"></div>
                        <div className="flex-1">
                          <div className="h-4 bg-muted rounded mb-2"></div>
                          <div className="h-3 bg-muted rounded mb-1"></div>
                          <div className="h-3 w-1/2 bg-muted rounded"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {recentActions && recentActions.length > 0 ? (
                      recentActions.slice(0, 5).map((action, index) => (
                        <div key={action.id} className="flex items-start space-x-4 p-4 bg-muted/30 rounded-lg" data-testid={`activity-${index}`}>
                          <div className="w-8 h-8 bg-destructive/10 rounded-lg flex items-center justify-center mt-1">
                            {getActionIcon(action.type)}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <p className="font-medium text-foreground" data-testid={`activity-action-${index}`}>
                                {action.type.charAt(0).toUpperCase() + action.type.slice(1)} action
                              </p>
                              <span className="text-xs text-muted-foreground" data-testid={`activity-time-${index}`}>
                                {formatTimeAgo(action.createdAt)}
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1" data-testid={`activity-description-${index}`}>
                              {action.targetUsername !== 'N/A' 
                                ? `${action.targetUsername} was ${action.type}ed${action.reason ? ` for "${action.reason}"` : ''}`
                                : action.reason || 'Moderation action performed'
                              }
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              Moderator: <span className="text-foreground" data-testid={`activity-moderator-${index}`}>{action.moderatorUsername}</span>
                            </p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-muted-foreground" data-testid="no-activity-message">
                        <Clock className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p>No recent activity</p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
      );
}
