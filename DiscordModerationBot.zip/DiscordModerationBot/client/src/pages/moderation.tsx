import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, 
  Ban,
  UserX,
  Volume2,
  VolumeX,
  Trash2,
  CheckCircle,
  AlertTriangle,
  Clock
} from "lucide-react";

interface ModerationAction {
  id: string;
  type: string;
  targetUsername: string;
  moderatorUsername: string;
  reason: string | null;
  createdAt: Date;
  duration: number | null;
}

interface CommandStats {
  ban: { usesToday: number; successRate: number };
  unban: { usesToday: number; successRate: number };
  kick: { usesToday: number; successRate: number };
  mute: { usesToday: number; activeMutes: number };
  unmute: { usesToday: number; successRate: number };
  clear: { usesToday: number; messagesCleared: number };
}

export default function Moderation() {
  const { data: recentActions, isLoading: actionsLoading } = useQuery<ModerationAction[]>({
    queryKey: ['/api/moderation-actions'],
    refetchInterval: 10000,
  });

  const { data: commandStats, isLoading: commandStatsLoading } = useQuery<CommandStats>({
    queryKey: ['/api/command-stats'],
    refetchInterval: 60000,
  });

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) return `${hours} hours ago`;
    return `${minutes} minutes ago`;
  };

  const getActionIcon = (type: string) => {
    switch (type) {
      case 'ban': return <Ban className="w-4 h-4 text-destructive" />;
      case 'unban': return <CheckCircle className="w-4 h-4 text-success" />;
      case 'kick': return <UserX className="w-4 h-4 text-warning" />;
      case 'mute': return <VolumeX className="w-4 h-4 text-muted-foreground" />;
      case 'unmute': return <Volume2 className="w-4 h-4 text-success" />;
      case 'clear': return <Trash2 className="w-4 h-4 text-primary" />;
      default: return <Shield className="w-4 h-4" />;
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground" data-testid="page-title-moderation">Moderation Center</h2>
        <p className="text-muted-foreground">Manage server moderation and view recent actions</p>
      </div>

      {/* Command Statistics */}
      <Card>
        <CardHeader>
          <CardTitle>Command Statistics</CardTitle>
          <p className="text-sm text-muted-foreground">Usage statistics for moderation commands</p>
        </CardHeader>
        <CardContent>
          {commandStatsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="border border-border rounded-lg p-4 animate-pulse">
                  <div className="h-6 bg-muted rounded mb-3"></div>
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-3 bg-muted rounded"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="border border-border rounded-lg p-4" data-testid="moderation-card-ban">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-destructive/10 rounded-lg flex items-center justify-center">
                      <Ban className="w-4 h-4 text-destructive" />
                    </div>
                    <span className="font-medium text-foreground">/ban</span>
                  </div>
                  <Badge variant="outline" className="text-xs">Active</Badge>
                </div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <div>Uses today: <span className="text-foreground">{commandStats?.ban.usesToday || 0}</span></div>
                  <div>Success rate: <span className="text-success">{commandStats?.ban.successRate || 100}%</span></div>
                </div>
              </div>

              <div className="border border-border rounded-lg p-4" data-testid="moderation-card-kick">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-warning/10 rounded-lg flex items-center justify-center">
                      <UserX className="w-4 h-4 text-warning" />
                    </div>
                    <span className="font-medium text-foreground">/kick</span>
                  </div>
                  <Badge variant="outline" className="text-xs">Active</Badge>
                </div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <div>Uses today: <span className="text-foreground">{commandStats?.kick.usesToday || 0}</span></div>
                  <div>Success rate: <span className="text-success">{commandStats?.kick.successRate || 95}%</span></div>
                </div>
              </div>

              <div className="border border-border rounded-lg p-4" data-testid="moderation-card-mute">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-muted/50 rounded-lg flex items-center justify-center">
                      <VolumeX className="w-4 h-4 text-muted-foreground" />
                    </div>
                    <span className="font-medium text-foreground">/mute</span>
                  </div>
                  <Badge variant="outline" className="text-xs">Active</Badge>
                </div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <div>Uses today: <span className="text-foreground">{commandStats?.mute.usesToday || 0}</span></div>
                  <div>Active mutes: <span className="text-warning">{commandStats?.mute.activeMutes || 0}</span></div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Moderation Actions</CardTitle>
          <p className="text-sm text-muted-foreground">Latest moderation actions performed by moderators</p>
        </CardHeader>
        <CardContent>
          {actionsLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center justify-between p-4 border border-border rounded-lg animate-pulse">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-muted rounded-lg"></div>
                    <div>
                      <div className="h-4 w-32 bg-muted rounded mb-1"></div>
                      <div className="h-3 w-24 bg-muted rounded"></div>
                    </div>
                  </div>
                  <div className="h-3 w-16 bg-muted rounded"></div>
                </div>
              ))}
            </div>
          ) : recentActions && recentActions.length > 0 ? (
            <div className="space-y-3">
              {recentActions.map((action) => (
                <div key={action.id} className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/30 transition-colors" data-testid={`action-${action.type}-${action.id}`}>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-muted/50 rounded-lg flex items-center justify-center">
                      {getActionIcon(action.type)}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        {action.type} - {action.targetUsername}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        by {action.moderatorUsername} • {action.reason || 'No reason provided'}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">
                      {formatTimeAgo(action.createdAt)}
                    </p>
                    {action.duration && (
                      <p className="text-xs text-warning">
                        {action.duration}m duration
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Shield className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No moderation actions yet</p>
              <p className="text-sm text-muted-foreground">Actions will appear here when moderators use commands</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}