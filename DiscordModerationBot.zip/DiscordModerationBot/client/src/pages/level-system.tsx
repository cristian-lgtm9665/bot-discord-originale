import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  MessageCircle, 
  Mic, 
  Trophy,
  Star,
  Users
} from "lucide-react";

interface TopUser {
  id: string;
  username: string;
  level: number;
  xp: number;
  progressPercent: number;
  progressXP: number;
  requiredXP: number;
  messageCount: number;
  voiceJoins: number;
}

export default function LevelSystem() {
  const { data: topUsers, isLoading: usersLoading } = useQuery<TopUser[]>({
    queryKey: ['/api/top-users'],
    refetchInterval: 60000,
  });

  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground" data-testid="page-title-level-system">Level System</h2>
        <p className="text-muted-foreground">Manage XP rewards and user progression</p>
      </div>

      {/* XP Configuration */}
      <Card>
        <CardHeader>
          <CardTitle>XP Configuration</CardTitle>
          <p className="text-sm text-muted-foreground">Current XP reward settings</p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-medium text-foreground">XP Rewards</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg" data-testid="level-xp-setting-message">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
                      <MessageCircle className="w-4 h-4 text-success" />
                    </div>
                    <span className="text-sm text-foreground">Message XP</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-foreground">15</span>
                    <span className="text-xs text-muted-foreground">XP</span>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg" data-testid="level-xp-setting-voice">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center">
                      <Mic className="w-4 h-4 text-accent" />
                    </div>
                    <span className="text-sm text-foreground">Voice Join XP</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-foreground">50</span>
                    <span className="text-xs text-muted-foreground">XP</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-foreground">Level Command</h4>
              <div className="p-4 bg-muted/30 rounded-lg" data-testid="level-livello-command-info">
                <div className="flex items-center space-x-3 mb-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 text-primary" />
                  </div>
                  <span className="font-medium text-foreground">/livello</span>
                  <Badge variant="outline" className="text-xs bg-success/10 text-success border-success/20">Active</Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-3">Check user level and XP progress</p>
                <div className="text-xs text-muted-foreground space-y-1">
                  <div>Formula: Level = √(XP/100) + 1</div>
                  <div>Cooldown: 1 minute between messages</div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Leaderboard */}
      <Card>
        <CardHeader>
          <CardTitle>Top Level Users</CardTitle>
          <p className="text-sm text-muted-foreground">Users with the highest levels and XP</p>
        </CardHeader>
        <CardContent>
          {usersLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg animate-pulse">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-muted rounded-full"></div>
                    <div>
                      <div className="h-4 w-20 bg-muted rounded mb-1"></div>
                      <div className="h-3 w-16 bg-muted rounded"></div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="h-4 w-16 bg-muted rounded mb-1"></div>
                    <div className="w-32 bg-muted rounded-full h-2"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : topUsers && topUsers.length > 0 ? (
            <div className="space-y-3">
              {topUsers.map((user, index) => (
                <div key={user.id} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors" data-testid={`leaderboard-user-${user.id}`}>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      {index === 0 && <Trophy className="w-5 h-5 text-yellow-500" />}
                      {index === 1 && <Star className="w-5 h-5 text-gray-400" />}
                      {index === 2 && <Star className="w-5 h-5 text-amber-600" />}
                      {index > 2 && <span className="text-sm font-medium text-foreground">#{index + 1}</span>}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{user.username}</p>
                      <p className="text-xs text-muted-foreground">
                        {user.messageCount} messages • {user.voiceJoins} voice joins
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-sm font-medium text-foreground">Level {user.level}</span>
                      <span className="text-xs text-muted-foreground">({user.xp} XP)</span>
                    </div>
                    <div className="w-32">
                      <Progress value={user.progressPercent} className="h-2" />
                      <p className="text-xs text-muted-foreground mt-1">
                        {user.progressXP}/{user.requiredXP} to next level
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No users with XP yet</p>
              <p className="text-sm text-muted-foreground">Users will appear here as they gain XP from messages and voice chat</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Level Calculation Info */}
      <Card>
        <CardHeader>
          <CardTitle>Level Calculation</CardTitle>
          <p className="text-sm text-muted-foreground">How the level system works</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-muted/30 rounded-lg">
              <h4 className="font-medium text-foreground mb-2">XP Sources</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Sending messages: +15 XP (1 minute cooldown)</li>
                <li>• Joining voice channels: +50 XP</li>
              </ul>
            </div>
            <div className="p-4 bg-muted/30 rounded-lg">
              <h4 className="font-medium text-foreground mb-2">Level Formula</h4>
              <p className="text-sm text-muted-foreground">
                Level = Math.floor(√(XP / 100)) + 1
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                XP required for next level = (current_level²) × 100
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}